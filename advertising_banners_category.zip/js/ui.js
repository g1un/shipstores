/*ui.js*/
if(document.querySelector('.jq-selectbox')){
  $('select').styler();
}
/*end of ui.js*/

