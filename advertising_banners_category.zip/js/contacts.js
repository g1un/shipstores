/*contacts.js*/
if(document.querySelector('.jq-selectbox-main')){
  $('select').styler();
}
/*end of contacts.js*/

