$(document).ready(function(){
    $('#select_main').styler();
});
